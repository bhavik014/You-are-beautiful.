# YOU ARE BEAUTIFUL — Complete Project

This document contains the complete project description, hardware setup, software setup, architecture, troubleshooting, and full Python source code for the interactive CRT art installation.

## Concept
The CRT permanently displays **YOU ARE BEAUTIFUL**. A camera detects a visitor, shows their live image while the message remains visible, records for 15 seconds, then displays a QR code. The QR opens a local webpage where the visitor can watch and download their recording.

## Hardware
- CRT/vintage television
- Old Dell laptop running Ubuntu
- USB webcam
- Wi-Fi network
- Suitable cable/adapter from laptop to CRT
- Optional: analog CCTV/Handycam + USB video capture adapter

## Software
Ubuntu, Python 3, OpenCV, Flask, qrcode, Pillow and NumPy.

Install:

```bash
cd ~/BeautifulTV
python3 -m venv venv
source venv/bin/activate
pip install opencv-python flask "qrcode[pil]" numpy
```

Optional FFmpeg:

```bash
sudo apt update
sudo apt install ffmpeg
```

## Full code
Save as `~/BeautifulTV/beautiful.py`.

```python
import cv2
import os
import time
import socket
import threading
from pathlib import Path

import numpy as np
import qrcode
from flask import Flask, send_from_directory, render_template_string

APP_NAME = "YOU ARE BEAUTIFUL"
RECORD_SECONDS = 15
CAMERA_INDEX = 0
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
FPS = 20
SERVER_PORT = 5000
BASE_DIR = Path(__file__).resolve().parent
RECORDINGS_DIR = BASE_DIR / "recordings"
QR_DIR = BASE_DIR / "qr"
RECORDINGS_DIR.mkdir(exist_ok=True)
QR_DIR.mkdir(exist_ok=True)

app = Flask(__name__)

@app.route("/")
def home():
    return """
    <html><head><title>YOU ARE BEAUTIFUL</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>body{background:#111;color:white;font-family:Arial;text-align:center;padding:40px}h1{font-weight:normal;letter-spacing:3px}</style>
    </head><body><h1>YOU ARE BEAUTIFUL</h1><p>Scan the QR code on the TV to open your recording.</p></body></html>
    """

@app.route("/video/<filename>")
def video_page(filename):
    safe_name = os.path.basename(filename)
    video_url = f"/files/{safe_name}"
    return render_template_string("""
    <!doctype html><html><head><title>Your Moment</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>body{background:#111;color:#eee;font-family:Arial;text-align:center;padding:25px}h1{font-weight:normal;letter-spacing:3px}video{width:100%;max-width:900px;background:#000}.download{display:inline-block;margin-top:25px;padding:14px 25px;background:#fff;color:#000;text-decoration:none;border-radius:4px}</style>
    </head><body><h1>YOU ARE BEAUTIFUL</h1><p>This moment belongs to you.</p>
    <video controls playsinline><source src="{{ video_url }}" type="video/mp4"></video><br>
    <a class="download" href="{{ video_url }}" download>Download your video</a>
    </body></html>
    """, video_url=video_url)

@app.route("/files/<filename>")
def serve_file(filename):
    return send_from_directory(RECORDINGS_DIR, os.path.basename(filename), as_attachment=False)

def get_local_ip():
    try:
        sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8",80))
        ip=sock.getsockname()[0]
        sock.close()
        return ip
    except Exception:
        return "127.0.0.1"

def start_server():
    app.run(host="0.0.0.0",port=SERVER_PORT,debug=False,threaded=True)

def apply_crt_effect(frame):
    frame=cv2.resize(frame,(SCREEN_WIDTH,SCREEN_HEIGHT))
    frame=cv2.GaussianBlur(frame,(3,3),0)
    gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    gray=cv2.cvtColor(gray,cv2.COLOR_GRAY2BGR)
    frame=cv2.addWeighted(frame,0.65,gray,0.35,0)
    noise=np.random.normal(0,5,frame.shape).astype(np.float32)
    frame=np.clip(frame.astype(np.float32)+noise,0,255).astype(np.uint8)
    for y in range(0,SCREEN_HEIGHT,4):
        frame[y:y+1,:]=(frame[y:y+1,:]*0.72).astype(np.uint8)
    rows,cols=frame.shape[:2]
    kx=cv2.getGaussianKernel(cols,cols/2)
    ky=cv2.getGaussianKernel(rows,rows/2)
    mask=ky@kx.T
    mask=0.55+0.45*(mask/mask.max())
    return np.clip(frame.astype(np.float32)*mask[:,:,None],0,255).astype(np.uint8)

def draw_beautiful_text(frame):
    font=cv2.FONT_HERSHEY_SIMPLEX
    scale=1.35
    thickness=2
    size=cv2.getTextSize(APP_NAME,font,scale,thickness)[0]
    x=(SCREEN_WIDTH-size[0])//2
    y=80
    glow=frame.copy()
    cv2.putText(glow,APP_NAME,(x,y),font,scale,(230,230,230),7,cv2.LINE_AA)
    glow=cv2.GaussianBlur(glow,(21,21),0)
    frame=cv2.addWeighted(frame,0.82,glow,0.18,0)
    cv2.putText(frame,APP_NAME,(x,y),font,scale,(235,235,235),thickness,cv2.LINE_AA)
    return frame

camera=cv2.VideoCapture(CAMERA_INDEX)
camera.set(cv2.CAP_PROP_FRAME_WIDTH,SCREEN_WIDTH)
camera.set(cv2.CAP_PROP_FRAME_HEIGHT,SCREEN_HEIGHT)
camera.set(cv2.CAP_PROP_FPS,FPS)
if not camera.isOpened():
    print("ERROR: Camera could not be opened. Try CAMERA_INDEX = 1 or 2.")
    raise SystemExit

cascade_path=cv2.data.haarcascades+"haarcascade_frontalface_default.xml"
face_detector=cv2.CascadeClassifier(cascade_path)

def record_video():
    print("Recording started.")
    filename="beautiful_"+time.strftime("%Y%m%d_%H%M%S")+".mp4"
    output_path=RECORDINGS_DIR/filename
    writer=cv2.VideoWriter(str(output_path),cv2.VideoWriter_fourcc(*"mp4v"),FPS,(SCREEN_WIDTH,SCREEN_HEIGHT))
    start=time.time()
    while time.time()-start<RECORD_SECONDS:
        ret,frame=camera.read()
        if not ret: continue
        frame=cv2.resize(frame,(SCREEN_WIDTH,SCREEN_HEIGHT))
        writer.write(frame)
        processed=draw_beautiful_text(apply_crt_effect(frame))
        remaining=max(0,RECORD_SECONDS-int(time.time()-start))
        cv2.putText(processed,"REC",(40,55),cv2.FONT_HERSHEY_SIMPLEX,1.1,(220,220,220),2,cv2.LINE_AA)
        cv2.putText(processed,str(remaining),(SCREEN_WIDTH-65,60),cv2.FONT_HERSHEY_SIMPLEX,1.2,(220,220,220),2,cv2.LINE_AA)
        cv2.imshow("YOU ARE BEAUTIFUL",processed)
        if cv2.waitKey(1)&0xFF==27: break
    writer.release()
    print("Recording saved:",output_path)
    return filename

def create_qr(filename):
    url=f"http://{get_local_ip()}:{SERVER_PORT}/video/{filename}"
    print("QR URL:",url)
    qr=qrcode.QRCode(version=1,error_correction=qrcode.constants.ERROR_CORRECT_M,box_size=10,border=4)
    qr.add_data(url); qr.make(fit=True)
    image=qr.make_image(fill_color="black",back_color="white")
    path=QR_DIR/"current_qr.png"
    image.save(path)
    return str(path)

def show_qr_screen(qr_path):
    qr=cv2.imread(qr_path)
    if qr is None: return
    qr=cv2.resize(qr,(520,520),interpolation=cv2.INTER_NEAREST)
    screen=np.full((SCREEN_HEIGHT,SCREEN_WIDTH,3),25,dtype=np.uint8)
    x=(SCREEN_WIDTH-qr.shape[1])//2; y=120
    screen[y:y+qr.shape[0],x:x+qr.shape[1]]=qr
    cv2.putText(screen,"THANK YOU",(470,75),cv2.FONT_HERSHEY_SIMPLEX,1.1,(240,240,240),2,cv2.LINE_AA)
    cv2.putText(screen,"SCAN TO KEEP YOUR MOMENT",(355,690),cv2.FONT_HERSHEY_SIMPLEX,0.9,(220,220,220),2,cv2.LINE_AA)
    cv2.imshow("YOU ARE BEAUTIFUL",screen)
    start=time.time()
    while time.time()-start<20:
        if cv2.waitKey(100)==27: break

threading.Thread(target=start_server,daemon=True).start()
print("YOU ARE BEAUTIFUL — waiting for visitor. Press ESC to exit.")
recording_in_progress=False
last_trigger_time=0
COOLDOWN_SECONDS=5

while True:
    ret,frame=camera.read()
    if not ret: continue
    frame=cv2.resize(frame,(SCREEN_WIDTH,SCREEN_HEIGHT))
    processed=draw_beautiful_text(apply_crt_effect(frame))
    gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    faces=face_detector.detectMultiScale(gray,scaleFactor=1.2,minNeighbors=5,minSize=(80,80))
    cv2.imshow("YOU ARE BEAUTIFUL",processed)
    if cv2.waitKey(1)==27: break
    now=time.time()
    if faces is not None and len(faces)>0 and not recording_in_progress and now-last_trigger_time>COOLDOWN_SECONDS:
        recording_in_progress=True
        last_trigger_time=now
        filename=record_video()
        show_qr_screen(create_qr(filename))
        recording_in_progress=False
        print("Waiting for next visitor...")

camera.release()
cv2.destroyAllWindows()
```

## Running
```bash
cd ~/BeautifulTV
source venv/bin/activate
python beautiful.py
```
Press ESC to exit.

## QR testing
Laptop and phone normally need the same Wi-Fi. Check the laptop IP with `hostname -I`. If the firewall blocks port 5000, use `sudo ufw allow 5000/tcp`. For a public exhibition, use a dedicated local hotspot or an internet-accessible upload service instead of relying on the laptop's private IP.

## Analog camera
Old CCTV/Handycam sources generally need a USB video capture device. Use `v4l2-ctl --list-devices` after installing `v4l-utils` to identify the correct camera device. Change `CAMERA_INDEX` if necessary.

## Vintage saved video
The TV display is processed with CRT effects, while the saved file is currently the camera recording. To save the processed look too, replace `writer.write(frame)` with `writer.write(processed)` after calculating the processed frame.

## Video compatibility
`mp4v` can be inconsistent across mobile browsers. If needed, install FFmpeg and add an automatic H.264 conversion step in a later version.

## Performance
For an old laptop, try `SCREEN_WIDTH = 960`, `SCREEN_HEIGHT = 540`, and `FPS = 15`.

## Privacy
Because visitors are recorded, put a clear notice near the installation and decide how long recordings remain stored. An automatic deletion policy is recommended for an exhibition.

## Physical arrangement
Hide the laptop behind/below the CRT where possible. Keep the camera visible. The desired feeling is that the CRT itself is the artwork and the computer is invisible.

## Artistic sequence
**Stranger → Camera → Recognition → YOU ARE BEAUTIFUL → 15 seconds → QR → Digital memory**

The old CRT connects the message to an analog broadcast aesthetic; the QR code connects that analog object to the visitor’s modern phone.

## Future V2
Possible additions include better motion/person detection, automatic deletion, H.264 conversion, public QR links, email delivery, multiple-visitor handling, CRT hum/tape hiss, stronger analog distortion, chromatic aberration, tracking distortion, and a physical “PRESS TO BE SEEN” button.

## Minimum checklist
- CRT TV
- Ubuntu laptop
- USB webcam
- TV/laptop connection
- Wi-Fi
- Python virtual environment
- OpenCV
- Flask
- QRCode
- `beautiful.py`
- Test recording
- Test QR scan
- Test video playback

## Project summary
**Title:** YOU ARE BEAUTIFUL

**Format:** Interactive audiovisual installation

**Core technology:** Python + OpenCV + Flask + QR

**Hardware:** CRT television + camera + old laptop

**Interaction:** Approximately 15 seconds per visitor

**Output:** Personal video accessed through a QR code

**Core idea:** A machine built from old technology looks at a stranger and gives them a message they normally do not receive from machines: **YOU ARE BEAUTIFUL.**
